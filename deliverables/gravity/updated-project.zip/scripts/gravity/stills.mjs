import {bundle} from '@remotion/bundler';
import {selectComposition,renderStill} from '@remotion/renderer';
const serveUrl=await bundle({entryPoint:process.cwd()+'/src/index.ts'});
const opts={serveUrl,id:'GravityShort',browserExecutable:'/usr/bin/chromium',chromiumOptions:{gl:'swangle'}};
const composition=await selectComposition(opts);
for(const frame of [15,165,330,412,600,855]){
 await renderStill({...opts,composition,frame,scale:0.5,output:`out/gravity/frame-${frame}.png`,timeoutInMilliseconds:120000});
 console.log('Still complete',frame);
}
