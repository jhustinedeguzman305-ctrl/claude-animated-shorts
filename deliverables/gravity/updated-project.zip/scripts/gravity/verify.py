import json, subprocess
from pathlib import Path
import numpy as np
p=Path('out/gravity/gravity-disappeared.mp4')
meta=json.loads(subprocess.check_output(['ffprobe','-v','error','-count_frames','-show_streams','-show_format','-of','json',str(p)]))
v=next(s for s in meta['streams'] if s['codec_type']=='video')
a=next(s for s in meta['streams'] if s['codec_type']=='audio')
assert (v['width'],v['height'],v['r_frame_rate'],int(v['nb_read_frames']))==(1080,1920,'30/1',900),v
assert abs(float(meta['format']['duration'])-30)<0.05
raw=subprocess.check_output(['ffmpeg','-v','error','-i',str(p),'-vf','scale=108:192','-pix_fmt','rgb24','-f','rawvideo','-'])
f=np.frombuffer(raw,np.uint8).reshape(-1,192,108,3)
means=f.mean(axis=(1,2,3));delta=np.abs(np.diff(f.astype(np.float32),axis=0)).mean(axis=(1,2,3))
report={'frames':len(f),'duration':meta['format']['duration'],'width':v['width'],'height':v['height'],'fps':v['r_frame_rate'],'audio_codec':a['codec_name'],'black_frames':int((means<5).sum()),'white_frames':int((means>250).sum()),'identical_adjacent_frames':int((delta==0).sum()),'minimum_frame_mean':float(means.min()),'maximum_frame_mean':float(means.max())}
assert report['black_frames']==0 and report['white_frames']==0
Path('out/gravity/verification.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
