"""Original synthesized score and sound effects; no sampled third-party audio."""
from pathlib import Path
import numpy as np
from scipy.io.wavfile import write
SR=48000
DURATION=30
rng=np.random.default_rng(341)
mix=np.zeros((SR*DURATION,2),dtype=np.float64)
def add(start, x, gain=1, pan=0):
    i=round(start*SR); n=min(len(x),len(mix)-i)
    if n<=0:return
    gains=np.array([np.sqrt((1-pan)/2),np.sqrt((1+pan)/2)])
    mix[i:i+n]+=x[:n,None]*gain*gains

def tone(freq,dur,decay=3):
    t=np.arange(round(SR*dur))/SR
    env=(1-np.exp(-t*100))*np.exp(-t*decay)*np.minimum(1,(dur-t)*60)
    return (np.sin(2*np.pi*freq*t)+.23*np.sin(2*np.pi*freq*2*t))*env

def sweep(start,dur,f0,f1,gain=.15):
    t=np.arange(round(SR*dur))/SR
    env=np.sin(np.pi*t/dur)**2
    phase=2*np.pi*(f0*t+(f1-f0)*t*t/(2*dur))
    add(start,np.sin(phase)*env,gain)
# Airy rising question in the opening, gentle pizzicato curiosity bed.
sweep(0,.7,120,650,.16)
chords=[[220,261.626,329.628],[174.614,220,261.626],[196,246.942,293.665],[164.814,196,246.942]]
for beat in range(60):
    at=beat*.5
    chord=chords[(beat//8)%4]
    duck=.45 if 8<=at<14 else 1
    add(at,tone(chord[beat%3]*2,.42,7),.045*duck,(-1 if beat%2 else 1)*.35)
    if beat%4==0:add(at,tone(chord[0]/2,1.25,3),.055*duck)
# Cartoony push, loss of gravity and five-second countdown.
sweep(7.9,.28,180,800,.13)
sweep(8,.65,850,170,.09)
for sec in range(9,13):add(sec,tone(1046.5,.11,21),.065)
# Gravity returns: falling whistle and soft impact.
sweep(13,.55,900,130,.16)
t=np.arange(int(.42*SR))/SR
impact=(np.sin(2*np.pi*(75*t-50*t*t))+.35*rng.normal(0,1,len(t)))*np.exp(-t*16)
add(14,impact,.20)
# Explanation punctuation and resolved callback cadence.
for at,freq in [(16,659.25),(20,783.99),(25,523.25),(28.3,659.25),(28.6,783.99),(29,1046.5)]:add(at,tone(freq,.8,5),.075)
# Fade edges and bound peaks; stereo signed PCM16.
fade=int(.18*SR); mix[:fade]*=np.linspace(0,1,fade)[:,None];mix[-fade:]*=np.linspace(1,0,fade)[:,None]
peak=np.max(np.abs(mix)); mix*=min(1,.78/peak)
out=Path(__file__).resolve().parents[2]/'public/gravity/mix.wav';out.parent.mkdir(parents=True,exist_ok=True)
write(out,SR,(mix*32767).astype(np.int16))
print(f'{out}: {len(mix)/SR:.3f}s, {SR}Hz stereo, peak {20*np.log10(np.max(np.abs(mix))):.2f} dBFS')
