import React, {useMemo} from 'react';
import * as THREE from 'three';
import {AbsoluteFill, useCurrentFrame} from 'remotion';
import {ThreeCanvas} from '@remotion/three';
import {useThree} from '@react-three/fiber';

const INK='#251d35';
const clamp=(v:number)=>Math.min(1,Math.max(0,v));
const smooth=(v:number)=>{v=clamp(v);return v*v*(3-2*v)};
const captions=[
[0,2,'GRAVITY: GONE.','For just five seconds…'],
[2,5,'Would you fly away?','Not without a push.'],
[5,8,'A tiny thought experiment','Ground and air stay put.'],
[8,10.5,'One gentle push…','No gravity to pull you back.'],
[10.5,13,'You keep moving upward.','Same speed. No magic launch.'],
[13,14,'Then gravity returns.','Gravity pulls you down.'],
[14,18.5,'And down you come.','The landing is the problem.'],
[18.5,22,'No push? No lift-off.','Weightlessness is not an upward force.'],
[22,26,'Motion keeps going…','Until a force changes it.'],
[26,30,'Five seconds feels short.','The ground would disagree.'],
] as const;

function pose(t:number){
 if(t<2)return {y:2.1+0.4*t,rot:0.08*Math.sin(t*2),mood:'shock'};
 if(t<8)return {y:0,rot:0,mood:t>5?'happy':'think'};
 if(t<13)return {y:(t-8)*0.8,rot:0.05*Math.sin((t-8)*1.5),mood:'shock'};
 if(t<14.1){const d=t-13;return {y:Math.max(0,4+.8*d-4.905*d*d),rot:-.1*d,mood:'shock'}}
 return {y:0,rot:0,mood:t<18.5?'ouch':t>26?'happy':'think'};
}

const Character:React.FC<{x:number,z:number,t:number,friend?:boolean}> = ({x,z,t,friend=false})=>{
 const {camera}=useThree();
 const {canvas,texture}=useMemo(()=>{const canvas=document.createElement('canvas');canvas.width=400;canvas.height=700;const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;return {canvas,texture}},[]);
 const p=friend?{y:0,rot:0,mood:t>=8&&t<15?'shock':'think'}:pose(t);
 const c=canvas.getContext('2d')!;c.clearRect(0,0,400,700);c.lineCap='round';c.lineJoin='round';c.strokeStyle=INK;c.lineWidth=13;
 const line=(pts:number[])=>{c.beginPath();c.moveTo(pts[0],pts[1]);for(let i=2;i<pts.length;i+=2)c.lineTo(pts[i],pts[i+1]);c.stroke()};
 const fl=p.y>0;const bend=fl?Math.sin(t*2)*16:Math.sin(t*1.2)*2;
 // Single-stroke limbs and clear feet.
 line([180,420,160-bend,520,145-bend,645,110-bend,645]);line([220,420,250+bend,530,260+bend,645,292+bend,645]);
 line(fl?[150,295,95,240+bend,60,190+bend]:[150,295,100,375+bend,75,385+bend]);
 line(fl?[250,295,300,240-bend,340,185-bend]:[250,295,295,365-bend,325,350-bend]);
 c.fillStyle=friend?'#ffb546':'#38cbd7';c.beginPath();c.moveTo(155,265);c.quadraticCurveTo(200,245,245,265);c.lineTo(238,427);c.quadraticCurveTo(200,452,160,427);c.closePath();c.fill();c.stroke();
 c.fillStyle='#fff0d8';c.beginPath();c.moveTo(199,46);c.bezierCurveTo(95,43,96,150,119,205);c.bezierCurveTo(145,260,255,258,278,195);c.bezierCurveTo(310,122,269,42,199,46);c.fill();c.stroke();
 c.fillStyle=friend?'#ed693d':'#3e426c';c.beginPath();c.moveTo(112,116);c.quadraticCurveTo(100,32,203,32);c.quadraticCurveTo(275,30,285,105);c.lineTo(250,81);c.lineTo(217,108);c.lineTo(180,80);c.closePath();c.fill();c.stroke();
 const blink=Math.floor(t*60)%149<5;c.fillStyle=INK;
 if(blink){line([157,151,174,151]);line([220,151,237,151]);}else {c.beginPath();c.ellipse(165,151,8,p.mood==='shock'?17:11,0,0,7);c.ellipse(229,151,8,p.mood==='shock'?17:11,0,0,7);c.fill();}
 c.lineWidth=7;line([148,125,176,119]);line([215,119,242,125]);c.beginPath();
 if(p.mood==='shock'){c.ellipse(197,204,17,23,0,0,7);c.fill();}else if(p.mood==='ouch'){line([177,209,187,199,198,210,211,198,222,208]);}else {c.moveTo(174,197);c.quadraticCurveTo(197,p.mood==='happy'?224:201,220,197);c.stroke();}
 if(!friend){c.fillStyle='#fcf2d9';c.fillRect(183,293,34,9);}
 texture.needsUpdate=true;
 const q=new THREE.Quaternion().copy(camera.quaternion);q.multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0,0,1),p.rot));
 return <group position={[x,p.y,z]}><mesh position={[0,1.55,0]} quaternion={q}><planeGeometry args={[1.78,3.12]}/><meshBasicMaterial map={texture} transparent side={THREE.DoubleSide} depthWrite={false}/></mesh><mesh rotation={[-Math.PI/2,0,0]} position={[0,.018-p.y,0]} scale={[1/(1+p.y*.15),1/(1+p.y*.15),1]}><circleGeometry args={[.52,28]}/><meshBasicMaterial color="#343054" transparent opacity={.23/(1+p.y*.2)} depthWrite={false}/></mesh></group>
};

const Box:React.FC<{pos:[number,number,number],size:[number,number,number],color:string}>=({pos,size,color})=><mesh position={pos}><boxGeometry args={size}/><meshToonMaterial color={color}/><lineSegments><edgesGeometry args={[new THREE.BoxGeometry(...size)]}/><lineBasicMaterial color={INK}/></lineSegments></mesh>;
function World({t}:{t:number}){
 const {camera}=useThree();
 let look=new THREE.Vector3(0,2.4,0),pos=new THREE.Vector3(6,5.2,13);
 if(t<2){look.set(-.4,3.4+.3*t,0);pos.set(1.7-.35*t,4.4+.3*t,8.5-.3*t)}
 else if(t<8){const k=smooth((t-2)/6);look.set(0,1.5,0);pos.set(5-2*k,3.8,12-k)}
 else if(t<14.1){const y=pose(t).y;look.set(-.25,2.1+y*.65,0);pos.set(3-1.5*smooth((t-8)/6),4+y*.65,14)}
 else if(t<18.5){look.set(-.8,1.5,0);pos.set(1.3,2.8,8.6-.15*(t-14.1))}
 else if(t<26){look.set(.2,1.7,0);pos.set(4-.25*(t-18.5),3.3,12)}
 else {look.set(-.1,1.7,0);pos.set(2+.18*(t-26),3.6,10+.25*(t-26))}
 camera.position.copy(pos);camera.lookAt(look);camera.updateMatrixWorld();
 const h=pose(t).y;
 return <><color attach="background" args={['#78b9e9']}/><fog attach="fog" args={['#b2d7ee',24,70]}/><ambientLight intensity={1.5}/><directionalLight position={[5,12,7]} intensity={2.2} color="#ffe6b6"/>
 <mesh rotation={[-Math.PI/2,0,0]}><planeGeometry args={[160,160]}/><meshToonMaterial color="#8bc48c"/></mesh>
 <Box pos={[0,-.15,0]} size={[15,.3,14]} color="#eed4a5"/>
 {Array.from({length:12},(_,i)=><Box key={'p'+i} pos={[-6+i*1.1,.012,0]} size={[.025,.02,14]} color="#c5ae85"/>)}
 {Array.from({length:9},(_,i)=><Box key={'q'+i} pos={[0,.013,-6+i*1.5]} size={[15,.02,.025]} color="#c5ae85"/>)}
 {[-10,-6,-2,2,6,10].map((x,i)=><group key={x}><Box pos={[x,3+(i%2)*.7,-10]} size={[3.5,6+(i%2)*1.4,3]} color={['#ef9c7e','#e9c86a','#8ab6bc'][i%3]}/><mesh position={[x,6.8+(i%2)*1.4,-10]} rotation={[0,Math.PI/4,0]}><coneGeometry args={[2.6,2,4]}/><meshToonMaterial color="#b35f60"/></mesh>{[1.4,3.5,5.5].map(y=><Box key={y} pos={[x,y,-8.47]} size={[1.25,.95,.09]} color="#49758b"/>)}</group>)}
 {[-1,1].flatMap(side=>[0,5,10].map((z,i)=><group key={`${side}${z}`} position={[side*(7+i*.7),0,-z]}><Box pos={[0,1.3,0]} size={[.35,2.6,.35]} color="#92634c"/><mesh position={[0,3.2,0]}><icosahedronGeometry args={[1.6,1]}/><meshToonMaterial color={i%2?'#58a97a':'#75ba71'}/></mesh></group>))}
 <Box pos={[3,.7,-2]} size={[2.8,.15,.7]} color="#c18b55"/><Box pos={[3,1.35,-2.3]} size={[2.8,.8,.12]} color="#c18b55"/>{[2,4].map(x=><Box key={x} pos={[x,.35,-2]} size={[.13,.7,.5]} color="#3c4857"/>)}
 <Character x={-.9} z={0} t={t}/><Character x={1.45} z={-.2} t={t} friend/>
 {t>=8&&t<13&&[0,1,2].map(i=><mesh key={i} position={[-.9,Math.max(.2,h-i*.7),-.1]} rotation={[-Math.PI/2,0,0]}><ringGeometry args={[.65,.68,40]}/><meshBasicMaterial color="#faf3c8" transparent opacity={.25}/></mesh>)}
 </>;
}
export const GravityShort:React.FC=()=>{
 const f=useCurrentFrame(),t=f/30;const beat=captions.find(c=>t>=c[0]&&t<c[1])!;const off=t>=8&&t<13;
 return <AbsoluteFill style={{background:'#78b9e9',fontFamily:'Arial, sans-serif'}}>
 <ThreeCanvas width={1080} height={1920} camera={{fov:43,near:.1,far:160}} gl={{antialias:true,alpha:false}}><World t={t}/></ThreeCanvas>
 <AbsoluteFill style={{background:'linear-gradient(180deg,rgba(13,29,53,.32),transparent 26%,transparent 63%,rgba(13,29,53,.73))',pointerEvents:'none'}}/>
 <div style={{position:'absolute',top:115,left:75,right:75,color:'white',fontSize:27,fontWeight:800,letterSpacing:5}}>THE FIVE-SECOND EXPERIMENT</div>
 <div style={{position:'absolute',top:180,left:75,right:75,color:'#fff7d7',fontSize:t<2?91:64,lineHeight:1.03,fontWeight:900,textShadow:'0 4px 0 #24304a'}}>{t<2?'WHAT IF GRAVITY DISAPPEARED?':off?`GRAVITY OFF · ${(13-t).toFixed(1)}s`:t>=13&&t<18.5?'GRAVITY IS BACK':t<8?'FIRST, SET THE RULES':'THE SCIENCE OF THE FALL'}</div>
 {t>=5&&t<8&&<div style={{position:'absolute',top:410,left:75,right:75,padding:22,borderRadius:20,background:'#24314ee8',color:'#fff',fontSize:32,lineHeight:1.3}}>Simplified local scenario:<br/>gravity off; Earth and air held fixed. Ignore air drag.</div>}
 {off&&<div style={{position:'absolute',left:75,right:75,top:365,height:12,borderRadius:6,background:'#ffffff55'}}><div style={{height:'100%',width:`${(13-t)/5*100}%`,background:'#ffdc75',borderRadius:6}}/></div>}
 <div style={{position:'absolute',bottom:215,left:70,right:70,textAlign:'center',color:'white',fontWeight:900,fontSize:67,lineHeight:1.1,textShadow:'0 4px 2px #152239',background:'#172b42e8',borderRadius:28,padding:'30px 28px'}}>{beat[2]}<div style={{fontWeight:600,fontSize:39,lineHeight:1.25,color:'#ffe7a8',marginTop:18}}>{beat[3]}</div></div>
 <div style={{position:'absolute',bottom:145,left:75,right:75,color:'#ffffffd0',fontSize:25,letterSpacing:2}}>A PHYSICS THOUGHT EXPERIMENT · 30 SECONDS</div>
 </AbsoluteFill>
};
