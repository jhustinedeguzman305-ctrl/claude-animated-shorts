import React from 'react';
import {Composition} from 'remotion';
import {BridgeShort, BRIDGE_FRAMES} from './videos/bridge/Bridge';
import {GravityShort} from './videos/gravity/Gravity';
export const Root: React.FC = () => <><Composition id="BridgeShort" component={BridgeShort} durationInFrames={BRIDGE_FRAMES} fps={30} width={1080} height={1920}/><Composition id="GravityShort" component={GravityShort} durationInFrames={900} fps={30} width={1080} height={1920}/></>;
